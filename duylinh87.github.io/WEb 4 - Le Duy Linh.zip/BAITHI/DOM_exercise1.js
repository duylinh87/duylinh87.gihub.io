// thay doi logo googole thanh yahoo
let google = document.getElementById ("hplogo");
let yahoo = "https://png2.kisspng.com/sh/97162ca1172325cbcbd04feb418f8c1a/L0KzQYm3U8IxN5ZofZH0aYP2gLBuTglicJD0Rd9qaXywfLFuj713baNuktH3LXPyfb78jvlkaaVuh9D8LXb1dba0lvVkfJD3RetqaHByPYbogsBiOZVoTaZrMHK7Poq7VMI4PWI3Sac7MUW1RYO4UsM1PmoziNDw/kisspng-yahoo-mail-logo-verizon-communications-free-vector-yahoo-5ab0a1dc54b0b8.9442751215215252123469.png";

google.src = yahoo
google.srcset = yahoo



// tim kiem 
let sech = document.getElementsByClassName("gLFyf gsfi")
sech[0].title =" yahoo"













